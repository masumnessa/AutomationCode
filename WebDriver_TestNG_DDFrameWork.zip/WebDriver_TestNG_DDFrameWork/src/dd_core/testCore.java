package dd_core;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import dd_util.TestConfig;
import dd_util.Xls_Reader;
import dd_util.monitoringMail;

public class testCore {
	
/*This class will initialize the properties file
* Loading the xls file // We have saved the excel file the path of dd_properties packages as testdata.xlsx
* Initializing WebDriver
* Creating db connection
*Generating logs
*/

	
//Here we are loading the properties file that we have created under the
// dd_prperties packages
	
public static  Properties config = new 	Properties();
public static  Properties object = new 	Properties();
public static Xls_Reader  excel=null; 
public static WebDriver driver = null;



@BeforeSuite
public static  void  init() throws IOException{
if (driver== null){
//loading the config.property files and in the ()will put the path of config.prperties file
//System.getProperty("user.dir")is the dynamic way to write path
FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"//src//dd_properties//config.properties");	
config.load(fis);

//loading the object.property files

fis = new FileInputStream(System.getProperty("user.dir")+"//src//dd_properties//object.properties");
object.load(fis);


//Loading xls test data file(Path will be from testdata.xlsx file under dd_properties package)

excel= new Xls_Reader(System.getProperty("user.dir")+"//src//dd_properties//testData.xlsx");

//Here we r making it more dynamic so we can  work with any browser/

if (config.getProperty("browser").equals("firefox")){
	driver =new FirefoxDriver();
	  }else if (config.getProperty("browser").equals("ie")){
		  System.setProperty("WebDriver.ie.driver", "IEDriverServer.exe");
		  driver=new InternetExplorerDriver();
	  }else if (config.getProperty("browser").equals("chrome")){
		  System.setProperty("WebDriver.chrome.driver", "chromedriver.exe");
		  driver =new ChromeDriver();
	  }




//Implicit wait 

driver.manage().timeouts().implicitlyWait(30L, TimeUnit.SECONDS);
driver.get(config.getProperty("testsite"));
}



}

@AfterSuite
public static void QuitDriver() throws AddressException, MessagingException{
	
driver.quit();
	
monitoringMail mail = new monitoringMail();
mail.sendMail(TestConfig.server, TestConfig.from, TestConfig.to, TestConfig.subject, TestConfig.messageBody, TestConfig.attachmentPath, TestConfig.attachmentName);	


}
}
