package dd_tests;

import org.junit.Test;
import org.openqa.selenium.By;

import dd_core.testCore;

public class LoginTest extends testCore {

@Test
public void doLogin(){
driver.findElement(By.xpath(object.getProperty("login"))).click();	
driver.findElement(By.xpath(object.getProperty("username"))).sendKeys("abc@gmail.com");
driver.findElement(By.xpath(object.getProperty("password"))).sendKeys("fhfgjg");
driver.findElement(By.xpath(object.getProperty("signin"))).click();
	
	
	
	}
}
